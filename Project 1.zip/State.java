public interface State {
    public Player getNextPlayer();
    public Integer getNumberOfMovesDone();
    public String toString();
}
