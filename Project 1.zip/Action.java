public interface Action {
    String toString();
}
