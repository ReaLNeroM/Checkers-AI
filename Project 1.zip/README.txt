CSC242: Project 1

Authors:
	Vladimir Maksimovski	Rowland Zhang

How to build project:
	import to Eclipse

How to run:
	Main() method contained in Game.java
	upon running, the game will prompt you to select the two playing agents
	the details of the selection will be displayed in the System console
	the completion of the different algorithms can be demonstraed by choosing the different
	agents to play against, or to have them play each other
