public class Game {
    public static void main(String args[]) {
        CheckersGame game = new CheckersGame();
        game.setupNewGame();
        game.playGame();
    }
}
